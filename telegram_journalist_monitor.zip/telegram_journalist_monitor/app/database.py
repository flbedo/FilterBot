from __future__ import annotations

import sqlite3
from pathlib import Path


class Database:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self._create_schema()

    def _create_schema(self) -> None:
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS processed_messages (
                source_key TEXT NOT NULL,
                message_id INTEGER NOT NULL,
                processed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                sent_at TEXT,
                PRIMARY KEY (source_key, message_id)
            )
            """
        )
        self.conn.commit()

    def is_processed(self, source_key: str, message_id: int) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM processed_messages WHERE source_key=? AND message_id=?",
            (source_key, message_id),
        ).fetchone()
        return row is not None

    def mark_processed(self, source_key: str, message_id: int, sent: bool) -> None:
        self.conn.execute(
            """
            INSERT OR IGNORE INTO processed_messages(source_key, message_id, sent_at)
            VALUES (?, ?, CASE WHEN ? THEN CURRENT_TIMESTAMP ELSE NULL END)
            """,
            (source_key, message_id, int(sent)),
        )
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()
